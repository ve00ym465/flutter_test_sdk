import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart';
import 'controller/bluetooth_controller.dart';
import 'controller/foreground_task_handler.dart';
import 'controller/location_controller.dart';

class BluetoothConnectPage extends StatefulWidget {
  const BluetoothConnectPage({Key? key}) : super(key: key);

  @override
  State<BluetoothConnectPage> createState() => _BluetoothConnectPageState();
}

class _BluetoothConnectPageState extends State<BluetoothConnectPage> {
  late final BluetoothController controller;
  DateTime? _lastBackPressed;
  late final LocationController locationController;

  // ------------------------------------------------------------------------//
  //  LIFECYCLE
  // ------------------------------------------------------------------------//

  @override
  void initState() {
    super.initState();
    controller = Get.put(BluetoothController(), permanent: true);
    locationController = Get.put(LocationController(), permanent: true);
    _requestRuntimePerms();
    _initForegroundService();
    FlutterForegroundTask.addTaskDataCallback(_onReceiveTaskData);
  }

  @override
  void dispose() {
    FlutterForegroundTask.removeTaskDataCallback(_onReceiveTaskData);
    super.dispose();
  }

  // ------------------------------------------------------------------------//
  //  FOREGROUND‑SERVICE SETUP
  // ------------------------------------------------------------------------//

  void _onReceiveTaskData(Object data) {
    /* use this if you ever send data back from the TaskHandler */
  }

  Future<void> _requestRuntimePerms() async {
    await Permission.notification.request();

    await [
      Permission.bluetoothScan,
      Permission.bluetoothConnect,
      Permission.bluetoothAdvertise,
      Permission.location,
      // Permission.foregroundServiceConnectedDevice,
    ].request();
  }

  Future<void> _initForegroundService() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'bluetooth_channel_id',
        channelName: 'Bluetooth Service',
        channelDescription: 'Keeps Bluetooth connected in background',
        // <‑‑ iconData no longer exists; the launcher icon will be used.
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: true,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        // replaces the old `interval` parameter
        eventAction: ForegroundTaskEventAction.repeat(5000),
        autoRunOnBoot: true,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
  }

  Future<void> _startService() => FlutterForegroundTask.startService(
    notificationTitle: 'BLE connection active',
    notificationText: 'Tap to return to the app',
    serviceTypes: [ForegroundServiceTypes.connectedDevice],
    callback: startCallback,
  );

  Future<void> _stopService() => FlutterForegroundTask.stopService();

  // ------------------------------------------------------------------------//
  //  UI
  // ------------------------------------------------------------------------//

  @override
  Widget build(BuildContext context) {
    const targetMac = '68:63:50:08:6B:85';

    return WillPopScope(
      onWillPop: () async {
        final now = DateTime.now();
        if (_lastBackPressed == null ||
            now.difference(_lastBackPressed!) > const Duration(seconds: 2)) {
          _lastBackPressed = now;
          Fluttertoast.showToast(msg: "Press back again to exit");
          return false; // prevent exit
        }
        return true; // exit app
      },
      child: WithForegroundTask(
        child: Scaffold(
          appBar: AppBar(title: const Text('BLE Background Demo')),
          body: Center(
            child: Obx(() {
              final connected = controller.isConnected.value;
              final brakeCount = controller.ecuDataParams.value.brakeCount;
              final position = locationController.currentPosition.value;

              final latitude = position?.latitude.toStringAsFixed(6) ?? '...';
              final longitude = position?.longitude.toStringAsFixed(6) ?? '...';
              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Status: ${connected ? "Connected" : "Disconnected"}'),
                  const SizedBox(height: 20),
                  if (connected) ...[
                    const SizedBox(height: 10),
                    Text('Brake Count: $brakeCount'),
                  ],
                  ElevatedButton(
                    onPressed: () async {
                      if (connected) {
                        await controller.disconnectCurrentDevice();
                        await _stopService();
                      } else {
                        await _requestRuntimePerms();
                        await _startService();
                        await controller.ensureBluetoothOn();
                        await controller.startScan(targetMac);
                      }
                    },
                    child: Text(connected ? 'Disconnect' : 'Connect'),
                  ),
                  const SizedBox(height: 20),
                  Text('Latitude: $latitude'),
                  Text('Longitude: $longitude'),
                ],
              );
            }),
          ),
        ),
      ),
    );
  }
}
