import 'dart:async';
import 'dart:developer' as developer;

import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';


class ECUDataParams {
  bool isConnected;
  bool isIgnited;
  bool isHazardActivated;
  bool isBrakeApplied;
  double batteryValue;
  int brakeCount;

  ECUDataParams({
    required this.isConnected,
    required this.isIgnited,
    required this.isHazardActivated,
    required this.isBrakeApplied,
    required this.batteryValue,
    required this.brakeCount,
  });
}

class BluetoothController extends GetxController {
  /// Replace with your service/characteristic UUIDs:
  final Guid deviceUUID = Guid("00001815-0000-1000-8000-00805f9b34fb");
  final Guid writeUUID  = Guid("00002a56-0000-1000-8000-00805f9b34fb");
  final Guid notifyUUID = Guid("00002a5a-0000-1000-8000-00805f9b34fb");

  /// Observables
  RxBool isScanning     = false.obs;
  RxBool isConnected    = false.obs;
  Rx<BluetoothDevice?> connectedDevice = Rx<BluetoothDevice?>(null);

  BluetoothCharacteristic? writeCharacteristic;
  StreamSubscription<List<ScanResult>>? scanSubscription;

  /// ECU data
  Rx<ECUDataParams> ecuDataParams = ECUDataParams(
    isConnected: false,
    isIgnited: false,
    isHazardActivated: false,
    isBrakeApplied: false,
    batteryValue: 0.0,
    brakeCount: 0,
  ).obs;

  /// Start scanning for the target device by MAC address
  Future<void> startScan(String targetMac) async {
    developer.log("Starting BLE scan for $targetMac...", name: "BLE");
    isScanning.value = true;

    FlutterBluePlus.startScan(timeout: const Duration(seconds: 10));

    scanSubscription = FlutterBluePlus.onScanResults.listen((results) {
      for (ScanResult result in results) {
        developer.log("Found Device: ${result.device.remoteId.str}", name: "BLE Scan");
        if (result.device.remoteId.str == targetMac) {
          developer.log("Target Device Found: $targetMac. Stopping scan...", name: "BLE");
          FlutterBluePlus.stopScan();
          connectToDevice(result.device);
          break;
        }
      }
    }, onError: (e) {
      developer.log("Scan Error: $e", name: "BLE", error: e);
      _showToast("Scan failed: $e");
    });
  }

  /// Connect to the given BLE device
  Future<void> connectToDevice(BluetoothDevice device) async {
    try {
      developer.log("Attempting to connect to device: ${device.remoteId.str}", name: "BLE");

      // If already connected to something else, disconnect
      await disconnectCurrentDevice();

      // Attempt fresh connection
      await device.connect();
      device.connectionState.listen((state) {
        if (state == BluetoothConnectionState.disconnected) {
          developer.log("Device disconnected unexpectedly", name: "BLE");

          isConnected.value = false;
          connectedDevice.value = null;

          ecuDataParams.update((val) => val?.isConnected = false);
          _showToast("Device disconnected.");
        }
      });

      connectedDevice.value = device;
      isConnected.value = true;
      ecuDataParams.update((val) => val?.isConnected = true);

      _showToast("Connected to Device!");
      developer.log("Successfully connected to device: ${device.remoteId.str}", name: "BLE");

      // Wait a bit before discovering services
      await Future.delayed(const Duration(seconds: 2));
      await discoverServicesAndWrite(device);
    } catch (e) {
      developer.log("Connection Failed: $e", name: "BLE", error: e);
      _showToast("Connection failed: $e");
    }
  }

  /// Discover the services of the connected device, locate relevant characteristics,
  /// perform the initial handshake, and subscribe for notifications
  Future<void> discoverServicesAndWrite(BluetoothDevice device) async {
    try {
      developer.log("Discovering services on device: ${device.remoteId.str}", name: "BLE");

      if (!isConnected.value) {
        developer.log("Device is not connected. Skip discovery.", name: "BLE");
        return;
      }

      List<BluetoothService> services = await device.discoverServices();

      for (var service in services) {
        developer.log("Found Service: ${service.uuid}", name: "BLE Services");

        if (service.uuid == deviceUUID) {
          developer.log("Matching Service Found: ${service.uuid}", name: "BLE Services");

          for (var characteristic in service.characteristics) {
            developer.log("Checking Characteristic: ${characteristic.uuid}", name: "BLE Char");

            // Store Write Characteristic
            if (characteristic.uuid == writeUUID && characteristic.properties.write) {
              developer.log("Found Write Characteristic: ${characteristic.uuid}", name: "BLE");
              writeCharacteristic = characteristic;

              // Wait briefly to prevent multiple writes at once
              await Future.delayed(const Duration(seconds: 1));
              await writeHandshakeData(characteristic);
            }

            // Enable Notifications for ECU Data
            if (characteristic.uuid == notifyUUID && characteristic.properties.notify) {
              developer.log("Subscribing to ECU Notifications: ${characteristic.uuid}", name: "BLE");

              await characteristic.setNotifyValue(true);
              characteristic.onValueReceived.listen((value) {
                parseECUData(value);
              });
              _showToast("Subscribed to ECU Data Notifications");
            }
          }
        }
      }

      developer.log("Service discovery completed.", name: "BLE");
    } catch (e) {
      developer.log("Service Discovery Failed: $e", name: "BLE", error: e);
      _showToast("Failed to discover services: $e");
    }
  }

  /// Parse the incoming notification data from the ECU
  void parseECUData(List<int> data) {
    // Example parsing (adjust based on your actual data structure):
    if (data.length < 6) return;

    developer.log("ECU Data Received: $data", name: "ECU Data");
    bool ignited          = (data[4] == 1);
    bool hazardActivated  = (data[5] == 1);
    bool brakeApplied     = (data[3] == 1);
    double batteryValue   = (data[1] << 8 | data[2]) / 1000.0;

    // Count brake presses
    int newBrakeCount = ecuDataParams.value.brakeCount;
    if (brakeApplied && !ecuDataParams.value.isBrakeApplied) {
      newBrakeCount++;
    }

    ecuDataParams.update((params) {
      if (params == null) return;
      params.isConnected       = true;
      params.isIgnited         = ignited;
      params.isHazardActivated = hazardActivated;
      params.isBrakeApplied    = brakeApplied;
      params.batteryValue      = batteryValue;
      params.brakeCount        = newBrakeCount;
    });
    // final engineController = Get.find<EngineController>();
    // engineController.brakeCount.value      = newBrakeCount;
    // engineController.batteryVoltage.value = batteryValue;
    // engineController.hazardStatus.value   = hazardActivated ? 'ON' : 'OFF';
    // if (ignited) {
    //   engineController.startEngine();
    // } else {
    //   engineController.stopEngine();
    // }
    //_showToast("ECU Data Updated: Ignition ${ignited ? 'ON' : 'OFF'}");
  }

  /// Write initial handshake data to the device
  Future<void> writeHandshakeData(BluetoothCharacteristic characteristic) async {
    try {
      List<int> handshakeData = [104, 112, 109, 0, 0, 0, 0, 0]; // Example data
      developer.log("Writing Handshake Data: $handshakeData", name: "BLE Write");
      await characteristic.write(handshakeData);

      _showToast("Handshake data sent successfully!");
      developer.log("Successfully wrote handshake data!", name: "BLE Write");
    } catch (e) {
      developer.log("Write Failed: $e", name: "BLE Write", error: e);
      _showToast("Handshake failed: $e");
    }
  }

  /// Various example commands
  Future<void> sendCommand(List<int> command, String description) async {
    if (writeCharacteristic == null) {
      _showToast("Write characteristic not found.");
      return;
    }
    try {
      developer.log("Writing Command: $command ($description)", name: "BLE Write");
      await writeCharacteristic!.write(command);
      _showToast("$description command sent!");
    } catch (e) {
      developer.log("Command Write Failed: $e", name: "BLE Write", error: e);
      _showToast("Write failed: $e");
    }
  }

  void sendHazardOn()    => sendCommand([76, 1, 0, 0, 0, 0, 0, 0], "Hazard On");
  void sendHazardOff()   => sendCommand([76, 0, 0, 0, 0, 0, 0, 0], "Hazard Off");
  void sendAnswerBack()  => sendCommand([65, 2, 0, 0, 0, 0, 0, 0], "Answer Back");
  void sendLocateMyBike() => sendCommand([66, 0, 0, 0, 0, 0, 0, 0], "Locate My Bike");

  /// Disconnect if already connected
  Future<void> disconnectCurrentDevice() async {
    if (connectedDevice.value != null) {
      await connectedDevice.value!.disconnect();
      connectedDevice.value = null;
      isConnected.value = false;
    }
  }

  /// Show a toast
  void _showToast(String message) {
    Fluttertoast.showToast(msg: message, toastLength: Toast.LENGTH_SHORT);
  }
  Future<void> ensureBluetoothOn() async {
    if (await FlutterBluePlus.isSupported == false) return;

    // Turn BT on automatically if you’re on Android
    if (await FlutterBluePlus.adapterState.first != BluetoothAdapterState.on) {
      await FlutterBluePlus.turnOn();
      await FlutterBluePlus.adapterState
          .where((s) => s == BluetoothAdapterState.on).first;
    }
  }


  @override
  void onClose() {
    scanSubscription?.cancel();
    disconnectCurrentDevice();
    super.onClose();
  }
}
